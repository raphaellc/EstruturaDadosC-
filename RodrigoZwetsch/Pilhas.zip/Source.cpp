#include <iostream>
#include "No.h"
#include "ListaPessoas.h"
#include "Lista.h"

//void percorreLista(No * no) {
//	if (no != nullptr) {
//		std::cout << no->pessoa->s_nome << std::endl;
//		percorreLista(no->proximo);
//	}
//}

int main() {
	
	ListaPessoas * lp_lista_pessoas = new ListaPessoas();
	
	Pessoa * pessoa1;
	//defini��o da lista
	// Defini��o de uma pessoa
	pessoa1 = new Pessoa;
	pessoa1->s_nome = "Daciolo";
	pessoa1->i_idade = 40;

	//adicionar esta pessoa no n�.
		
	lp_lista_pessoas->insereFimLista(pessoa1);
	//adicionar o n� na lista
	
	Pessoa * DEUX = new Pessoa;
	DEUX->s_nome = "DEUX";
	DEUX->i_idade = 0;
	
	//adicionar novo n� na lista
	lp_lista_pessoas->insereFimLista(DEUX);
	lp_lista_pessoas->percorreLista(lp_lista_pessoas->lista);

	system("pause");
	return 0;
}